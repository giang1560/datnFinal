using UnityEngine;
using System.Collections.Generic;

public class GhostManager : MonoBehaviour
{
    [Header("Settings")]
    public GameObject ghostPrefab;
    public RubikMap map;
    public MapCursor playerCursor; 

    private GameObject ghostInstance;
    private RubikSimulator ghostSimulator;
    private RubikSimulator simulator;
    // Biến lưu trạng thái bật/tắt (theo yêu cầu cũ của bạn)
    private bool isGhostEnabled = true; 

    void Start()
    {
        if (map != null) {
            simulator = new RubikSimulator(map); 
        }

        if (ghostPrefab != null)
        {
            ghostInstance = Instantiate(ghostPrefab);
            ghostInstance.SetActive(false);
            
            Collider col = ghostInstance.GetComponent<Collider>();
            if (col) col.enabled = false;
        }
    }

    public void SetGhostEnabled(bool isEnabled)
    {
        this.isGhostEnabled = isEnabled;
        if (!isEnabled) HideGhost();
    }

    // ✅ HÀM MỚI: Chỉ hiện Ghost cho 1 hướng duy nhất
    public void ShowPreview(Direction dir)
    {
        if (!isGhostEnabled || ghostInstance == null || simulator == null) return;

        ghostInstance.SetActive(true);
        SimulationResult result = simulator.SimulateSlide(playerCursor.CurrentCoord, dir);

        if (result.steps.Count > 0)
        {
            SimulationStep lastStep = result.steps[result.steps.Count - 1];
            SnapGhostToCoord(lastStep.coord);
        }
        else 
        {
            SnapGhostToCoord(playerCursor.CurrentCoord);
        }
    }
    

    public void HideGhost()
    {
        if (ghostInstance) ghostInstance.SetActive(false);
    }

    void SnapGhostToCoord(TileCoord c)
    {
        TileCell cell = map.GetTileCell(c);
        if (cell != null)
        {
            ghostInstance.transform.position = cell.transform.position;
            ghostInstance.transform.rotation = cell.transform.rotation;
        }
    }
}