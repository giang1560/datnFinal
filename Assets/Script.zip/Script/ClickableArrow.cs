using UnityEngine;
using UnityEngine.EventSystems;

public class ClickableArrow : MonoBehaviour, IPointerClickHandler, IPointerEnterHandler, IPointerExitHandler
{
    [Header("Settings")]
    public Direction direction; 
    public PlayerInputController playerInput;
    
    // ✅ MỚI: Tham chiếu GhostManager để gọi preview
    public GhostManager ghostManager; 

    [Header("Visual Feedback")]
    public GameObject highlightEffect;

    // Khi CLICK chuột -> Di chuyển thật
    public void OnPointerClick(PointerEventData eventData)
    {
        // Ẩn Ghost ngay khi click để đỡ vướng mắt
        if (ghostManager != null) ghostManager.HideGhost();

        switch (direction)
        {
            case Direction.Up:    playerInput.MoveUp(); break;
            case Direction.Down:  playerInput.MoveDown(); break;
            case Direction.Left:  playerInput.MoveLeft(); break;
            case Direction.Right: playerInput.MoveRight(); break;
        }
    }

    // Khi RÊ chuột vào -> Hiện Ghost
    public void OnPointerEnter(PointerEventData eventData)
    {
        if(highlightEffect) highlightEffect.SetActive(true);
        
        if (ghostManager != null)
        {
            ghostManager.ShowPreview(direction);
        }
    }

    // Khi RÊ chuột ra -> Ẩn Ghost
    public void OnPointerExit(PointerEventData eventData)
    {
        if(highlightEffect) highlightEffect.SetActive(false);
        
        if (ghostManager != null)
        {
            ghostManager.HideGhost();
        }
    }
}