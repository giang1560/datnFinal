using UnityEngine;
using System.Collections.Generic;

public class RubikSimulator
{
    private RubikMap map;
    private RubikNavigator navigator;

    public RubikSimulator(RubikMap map)
    {
        this.map = map;
        this.navigator = new RubikNavigator(map.mapSize);
    }

    public SimulationResult SimulateSlide(TileCoord start, Direction inputDir)
    {
        SimulationResult result = new SimulationResult();
        TileCoord current = start;
        Direction currentMoveDir = inputDir;

        // ✅ MỚI: Bộ nhớ tạm để giả lập các cổng đã dùng trong lượt đi này
        // (Để tránh Simulator sửa trực tiếp vào Map thật)
        HashSet<string> tempUsedTeleports = new HashSet<string>();

        int safetyLoop = 0;
        while (safetyLoop < 100) 
        {
            safetyLoop++;

            // 1. Tính ô tiếp theo
            TileCoord next = navigator.GetNextCoord(current, currentMoveDir);

            if (next.face != current.face)
            {
                Debug.Log($"<color=orange>[SIMULATOR]</color> Chuyển mặt logic: {current.face} (Dir: {currentMoveDir}) ➔ {next.face} (New Dir: {next.currentDir})");
            }

            // 2. Kiểm tra tường (logic cũ)
            if (!map.IsWalkable(next)) 
            {
                Debug.Log($"<color=red>[WALL]</color> Chạm tường tại: {next.face} ({next.x}, {next.y})");
                result.stopReason = StopReason.Wall;
                break;
            }

            // 3. Lấy thông tin ô đích
            TileCell cell = map.GetTileCell(next);
            if (cell == null) break;

            // 4. Cập nhật hướng
            currentMoveDir = next.currentDir;

            // 5. Ghi nhận bước đi
            SimulationStep step = new SimulationStep();
            step.coord = next;
            step.isFaceChange = (next.face != current.face);
            step.newDirection = next.currentDir;
            step.stepResult = StopReason.None;

            // 6. Xử lý logic
            switch (cell.Type)
            {
                case TileType.Trap:
                    step.stepResult = StopReason.Trap;
                    result.steps.Add(step);
                    result.stopReason = StopReason.Trap;
                    return result; 
                    
                case TileType.Sticky:
                    step.stepResult = StopReason.Sticky;
                    result.steps.Add(step);
                    result.stopReason = StopReason.Sticky;
                    return result; 
                    
                case TileType.Goal:
                    step.stepResult = StopReason.Goal;
                    result.steps.Add(step);
                    result.stopReason = StopReason.Goal;
                    return result; 

                case TileType.OneWay:
                    result.steps.Add(step);
                    current = next;
                    currentMoveDir = cell.specialData.oneWayDirection;
                    continue;
                    
                case TileType.Teleport:
                    // ✅ CHECK TẠM: Nếu cổng này đã dùng trong giả lập -> Coi là Floor
                    string key = next.ToString();
                    if (tempUsedTeleports.Contains(key))
                    {
                        // Coi như Floor, đi tiếp bình thường
                        result.steps.Add(step);
                        current = next;
                        continue;
                    }

                    // Nếu chưa dùng -> Tính toán Teleport
                    TileCoord teleportDest = map.GetTeleportDestination(next);
                    if (!teleportDest.Equals(next)) 
                    {
                        // ✅ KHÔNG SỬA MAP THẬT Ở ĐÂY NỮA (Đã xóa đoạn DisableTeleportPair)
                        
                        // Đánh dấu tạm vào HashSet để Simulator biết là đã dùng
                        tempUsedTeleports.Add(next.ToString());
                        tempUsedTeleports.Add(teleportDest.ToString());

                        // Thêm bước đi vào ô nguồn (để visual nhân vật trượt tới cổng)
                        result.steps.Add(step);

                        // Thêm bước dịch chuyển sang ô đích
                        SimulationStep teleStep = new SimulationStep();
                        teleStep.coord = teleportDest;
                        teleStep.isFaceChange = (teleportDest.face != next.face);
                        teleStep.stepResult = StopReason.Teleported;
                        result.steps.Add(teleStep);
                        
                        current = teleportDest;
                        continue;
                    }
                    else
                    {
                        // Lỗi link -> Dừng
                        result.stopReason = StopReason.Sticky;
                        return result;
                    }

                case TileType.Cracked:
                    // Logic cũ
                    result.steps.Add(step);
                    current = next;
                    continue;
                    
                default: // Floor
                    result.steps.Add(step);
                    current = next;
                    continue;
            }
        }

        if (result.stopReason == StopReason.None) result.stopReason = StopReason.Wall;
        return result;
    }
}