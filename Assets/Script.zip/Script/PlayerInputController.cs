using UnityEngine;

public class PlayerInputController : MonoBehaviour
{
    public MapCursor mapCursor;

    // Các hàm này gắn trực tiếp vào sự kiện OnClick của 4 Mũi tên UI
    // Mỗi mũi tên giữ một ID cố định, không bao giờ thay đổi.
    public void MoveUp()    => SendDirection(Direction.Up);   
    public void MoveDown()  => SendDirection(Direction.Down); 
    public void MoveLeft()  => SendDirection(Direction.Left); 
    public void MoveRight() => SendDirection(Direction.Right);

    private void SendDirection(Direction dir)
    {
        if (mapCursor != null && mapCursor.CanReceiveInput)
        {
            mapCursor.Move(dir);
        }
    }
}