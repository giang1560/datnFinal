using UnityEngine;
using System.Collections;

public class MapCursor : MonoBehaviour
{
    [Header("Ref")]
    public RubikMap map;
    public GameUIManager uiManager;

    [Header("Config")]
    public float stepSpeed = 0.2f;
    public int maxMoves = 3; 
    private int movesLeft;

    private TileCoord currentCoord;
    public TileCoord CurrentCoord => currentCoord;
    
    private RubikSimulator simulator;
    private bool isAnimating = false;
    
    public bool IsGameActive { get; private set; } = true;
    public bool CanReceiveInput => !isAnimating && IsGameActive && movesLeft > 0;


    void Start() {
        simulator = new RubikSimulator(map);
        ResetLevel();
    }

    // ✅ HÀM MOVE MỚI: Nhận hướng Visual -> Tính hướng Logical -> Gọi SlideRoutine
    public void Move(Direction dir) 
    {
        if (!CanReceiveInput) return;
        Debug.Log($"<color=cyan>[INPUT]</color> Người chơi bấm: <b>{dir}</b>");
        StartCoroutine(SlideRoutine(dir));
    }



   // ✅ SLIDE ROUTINE MỚI: Nhận cả 2 hướng


    IEnumerator SlideRoutine(Direction dir)
    {
        isAnimating = true;
        SimulationResult result = simulator.SimulateSlide(currentCoord, dir);

        movesLeft--;
        if (uiManager) uiManager.UpdateMoveCounter(movesLeft, maxMoves);

        foreach (SimulationStep step in result.steps)
        {
            // LOG 2: Khi nhân vật đổi mặt và kích hoạt xoay Pivot
            if (step.isFaceChange )
            {
                Debug.Log($"<color=magenta>[CAMERA]</color> Cần xoay camera sang mặt: {step.coord.face}");
                
            }

            // LOG 3: Vị trí hiện tại của nhân vật sau mỗi ô trượt
            Debug.Log($"<color=white>[MOVE]</color> Đang ở: {step.coord.face} | Tọa độ: ({step.coord.x}, {step.coord.y})");

            currentCoord = step.coord;
            TileCell targetCell = map.GetTileCell(step.coord);
            
            if (targetCell != null)
            {
                yield return StartCoroutine(MoveToCell(targetCell));
            }
        }

        // LOG 4: Kết thúc lượt trượt
        Debug.Log($"<color=green>[STOP]</color> Dừng lại do: {result.stopReason}");
        CheckGameStatus(result.stopReason);
        isAnimating = false;
    }
    
    // ... (Các hàm MoveToCell, SnapToCoord giữ nguyên) ...
    IEnumerator MoveToCell(TileCell targetCell)
    {
        Vector3 startPos = transform.position;
        Vector3 endPos = targetCell.transform.position;
        Quaternion startRot = transform.rotation;
        Quaternion endRot = targetCell.transform.rotation;
        float t = 0;
        while (t < 1f) {
            t += Time.deltaTime / stepSpeed;
            transform.position = Vector3.Lerp(startPos, endPos, t);
            transform.rotation = Quaternion.Lerp(startRot, endRot, t);
            yield return null;
        }
        transform.position = endPos;
        transform.rotation = endRot;
    }
    
    void SnapToCoord(TileCoord c) {
        TileCell cell = map.GetTileCell(c);
        if (cell) {
            transform.position = cell.transform.position;
            transform.rotation = cell.transform.rotation;
        }
    }

    public void ResetLevel() {
        StopAllCoroutines();
        isAnimating = false;
        IsGameActive = true;
        
        if (map != null) map.ResetAllTiles();
        
        map.transform.rotation = Quaternion.identity;

        movesLeft = maxMoves;
        if (uiManager != null) uiManager.UpdateMoveCounter(movesLeft, maxMoves);
        
        int mid = map.mapSize / 2;
        currentCoord = new TileCoord(FaceID.Top, mid, mid);
        SnapToCoord(currentCoord);
        
        if (uiManager != null) uiManager.HideAllPanels();
    }

    private void CheckGameStatus(StopReason reason)
    {
        if (uiManager == null) return;

        // Ưu tiên 1: Chết vì Bẫy
        if (reason == StopReason.Trap) 
        {
            IsGameActive = false; 
            uiManager.ShowLose(StopReason.Trap);
        }
        // Ưu tiên 2: Về Đích (Thắng)
        else if (reason == StopReason.Goal) 
        {
            IsGameActive = false;
            uiManager.ShowWin();
        }
        // Ưu tiên 3: Hết lượt
        else if (movesLeft <= 0)
        {
            IsGameActive = false;
            uiManager.ShowLose(StopReason.OutOfMoves);
        }
    }
}