using UnityEngine;

public class ArrowVisibilityManager : MonoBehaviour
{
    [Header("References")]
    public MapCursor mapCursor;
    public GameObject arrowContainer; // GameObject cha chứa cả 4 mũi tên

    void Update()
    {
        if (mapCursor == null || arrowContainer == null) return;

        // Chỉ hiện mũi tên khi nhân vật ĐANG ĐỨNG YÊN và GAME CHƯA KẾT THÚC
        bool shouldShow = mapCursor.CanReceiveInput;

        if (arrowContainer.activeSelf != shouldShow)
        {
            arrowContainer.SetActive(shouldShow);
        }
    }
}