using UnityEngine;

public class ArrowAnchor : MonoBehaviour
{
    [Header("Targets")]
    public Transform playerTarget;   // Kéo Player vào đây
    public Camera mainCamera;        // Kéo Main Camera (hoặc để trống tự tìm)

    [Header("Settings")]
    public Vector3 offset = Vector3.up * 1.5f; // Độ cao so với tâm nhân vật
    public bool detachOnStart = true; // Tự động tách khỏi Player lúc Start để tránh bị xoay theo

    void Start()
    {
        if (mainCamera == null) mainCamera = Camera.main;

        // Tự động tách cha để không bị ảnh hưởng bởi rotation của Player
        if (detachOnStart)
        {
            transform.SetParent(null); 
        }
    }

    void LateUpdate()
    {
        if (playerTarget == null || mainCamera == null) return;

        // 1. BÁM VỊ TRÍ (Follow Position)
        // Luôn đi theo Player + Offset
        transform.position = playerTarget.position + offset;

        // 2. KHÓA HƯỚNG (Billboard Rotation)
        // Luôn xoay cùng chiều với Camera -> Mũi tên Up sẽ luôn trùng hướng Up màn hình
        transform.rotation = mainCamera.transform.rotation;
    }
}