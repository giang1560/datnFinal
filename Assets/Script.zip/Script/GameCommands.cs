using UnityEngine;

public enum CommandType { Move } // Xóa Rotate

public interface ICommand
{
    CommandType Type { get; }
}

[System.Serializable]
public struct MoveCommand : ICommand
{
    public Direction direction;
    public CommandType Type => CommandType.Move;
    public MoveCommand(Direction dir) { this.direction = dir; }
}
// Xóa struct RotateCommand