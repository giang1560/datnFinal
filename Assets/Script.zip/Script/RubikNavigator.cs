using UnityEngine;

public class RubikNavigator
{
    private int mapSize;
    private int maxIndex; 
    private EdgeTransition[,] transitionTable;

    public RubikNavigator(int size)
    {
        this.mapSize = size;
        this.maxIndex = size - 1;
        this.transitionTable = RubikTopologyBuilder.BuildStandardCrossTopology();
    }

    public TileCoord GetNextCoord(TileCoord current, Direction dir)
    {
        int nx = current.x;
        int ny = current.y;

        // ✅ FIX: Matrix System chuẩn (Y tăng = đi lên, Y giảm = đi xuống)
        switch (dir) {
            case Direction.Up:    ny++; break;  // Up = tăng Y (đi từ dưới lên trên)
            case Direction.Down:  ny--; break;  // Down = giảm Y (đi từ trên xuống dưới)
            case Direction.Left:  nx--; break;  // Left = giảm X
            case Direction.Right: nx++; break;  // Right = tăng X
        }

        // Check Local Bounds
        if (nx >= 0 && nx <= maxIndex && ny >= 0 && ny <= maxIndex)
        {
            return new TileCoord(current.face, nx, ny) { currentDir = dir };
        }

        // Handle Transition
        return HandleFaceTransition(current.face, current.x, current.y, dir);
    }

    private TileCoord HandleFaceTransition(FaceID fromFace, int oldX, int oldY, Direction exitDir)
    {
        EdgeTransition rule = transitionTable[(int)fromFace, (int)exitDir];

        // 1. Tính Transversal Value (Giá trị chạy dọc cạnh)
        int transversalVal = (exitDir == Direction.Up || exitDir == Direction.Down) ? oldX : oldY;

        // 2. Flip tọa độ nếu cần
        if (rule.flipCoordinate) 
            transversalVal = maxIndex - transversalVal;

        // 3. ✅ FIX: TÍNH TỌA ĐỘ DựA TRÊN EDGE SIDE (Matrix System: Y=Max là Top, Y=0 là Bottom)
        int newX = 0, newY = 0;
        
        switch (rule.entrySide)
        {
            case EdgeSide.Top:    // Vào từ cạnh Trên → Y = MAX (trên cùng)
                newX = transversalVal; 
                newY = maxIndex;
                break;

            case EdgeSide.Bottom: // Vào từ cạnh Dưới → Y = 0 (dưới cùng)
                newX = transversalVal; 
                newY = 0;
                break;

            case EdgeSide.Left:   // Vào từ cạnh Trái → X = 0 (trái nhất)
                newX = 0;       
                newY = transversalVal; 
                break;

            case EdgeSide.Right:  // Vào từ cạnh Phải → X = MAX (phải nhất)
                newX = maxIndex;              
                newY = transversalVal; 
                break;
        }

        // 4. Trả về kết quả kèm hướng di chuyển mới
        return new TileCoord(rule.nextFace, newX, newY) 
        { 
            currentDir = rule.newMoveDirection 
        };
    }
}